def do_something():
  print("hello world!")
