_release = '31'
_version = '1.4-' + _release

def get_release():
    return _release

def get_version():
    return _version

